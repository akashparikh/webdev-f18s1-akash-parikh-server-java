
(function ()
{
    var $usernameFld, $passwordFld;
    var $removeBtn, $editBtn, $createBtn;
    var $firstNameFld, $lastNameFld;
    var $userRowTemplate, $tbody;
    var $roleFld;
    var userService = new AdminUserServiceClient();

    $(main);

    function main()
    {
        $usernameFld = $('#usernameFld');
        $passwordFld = $('#passwordFld');
        $editBtn=$('#updateBtn');
        $createBtn= $('#createBtn');
        $firstNameFld= $("#firstNameFld");
        $lastNameFld= $("#lastNameFld");
        $roleFld=$("#roleFld");
        $userRowTemplate=$(".wbdv-template.wbdv-user");
        $tbody=$(".wbdv-tbody");
        $createBtn.click(createUser);

    }

    function createUser()
    {
        var username = $usernameFld.val();
        $usernameFld.val("");
        var timestamp = (new Date()).getTime();
        var password = $passwordFld.val();
        $passwordFld.val("");
        var firstName= $firstNameFld.val();
        $firstNameFld.val("");
        var lastName= $lastNameFld.val();
        $lastNameFld.val("");
        var role= $roleFld.val();
        $roleFld.val("");
        var newUser = $userRowTemplate.clone();
        newUser.removeClass("wbdv-hidden");
        newUser.attr("id",timestamp);
        newUser.find(".wbdv-username").html(username);
        newUser.find(".wbdv-password").html(password);
        newUser.find(".wbdv-first-name").html(firstName);
        newUser.find(".wbdv-last-name").html(lastName);
        newUser.find(".wbdv-role").html(role);
        newUser.find(".wbdv-remove").attr("id",timestamp).click(deleteUser);
        newUser.find(".wbdv-edit").attr("id",timestamp).click(updateUser);

        $tbody.append(newUser);
    }

    function findAllUsers()
    {

    }
    function findUserById()
    {

    }
    function deleteUser(event)
    {
        //alert("hijhih");
        var button=$(event.currentTarget);
        var tr=button.parents(".wbdv-template");
        tr.remove();
    }
    function selectUser()
    {

    }
    function updateUser(event)
    {
        var button=$(event.currentTarget);
        var nm=button.parents(".wbdv-template");
        var mn=nm.find(".wbdv-username").html();
        //console.log(id);
        $usernameFld.val(mn);
        //var name=nm.find(".wbdv-username");
        //console.log(mn);
        var tr=button.parents(".wbdv-template");
        $editBtn.click(console.log("hi"));
        //$editBtn.click(createUser());
        //tr.remove();
    }
    function renderUser(user)
    {

    }
    function renderUsers(users)
    {

    }
})();
